//this is all about this keyword by hm NaYem 

 var myObj = {
     name : 'BayZid AhMed',
   print: function() {
    console.log(this);
    }
 };


 
